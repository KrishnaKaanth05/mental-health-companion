import React, { useState } from "react";
import "./App.css";
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis,
  Tooltip, CartesianGrid, ResponsiveContainer, Legend,
} from "recharts";

function App() {
  const [mood, setMood] = useState("");
  const [stress, setStress] = useState(5);
  const [journal, setJournal] = useState("");
  const [score, setScore] = useState(0);
  const [levelMessage, setLevelMessage] = useState("Let's start your wellness journey! 💙");
  const [activitySuggestions, setActivitySuggestions] = useState([]);
  const [personalRoutine, setPersonalRoutine] = useState([]);
  const [userMessage, setUserMessage] = useState("");
  const [chatMessages, setChatMessages] = useState([]);
  const [peerMessage, setPeerMessage] = useState("");
  const [peerMessages, setPeerMessages] = useState([]);

  const emojis = ["😊", "😢", "😡", "😌", "🥺", "😴", "😃"];
  const [moodHistory, setMoodHistory] = useState([]);
  const [stressHistory, setStressHistory] = useState([]);

  const handleCheckIn = () => {
    const time = new Date().toLocaleTimeString();
    setMoodHistory([...moodHistory, { time, mood }]);
    setStressHistory([...stressHistory, { time, stress }]);
    setScore(score + 10);

    let routine = [];
    if (stress >= 8) routine = ["🌬️ 5-min breathing", "📖 Journal thoughts", "🚶‍♂️ Short walk"];
    else if (mood.includes("😢")) routine = ["📖 Write positive memories", "🎧 Listen to calming music"];
    else if (mood.includes("😊")) routine = ["🚀 Try a new hobby", "🌳 Spend 10min in nature"];
    else routine = ["💧 Hydrate", "🧘 3-min mindfulness", "📱 Digital detox for 15 min"];

    setPersonalRoutine(routine);
    setActivitySuggestions([
      ...activitySuggestions,
      `Try this: ${routine[0]} — it'll help.`,
    ]);

    // Gamified encouragement
    if (score >= 50) setLevelMessage("Level Up! 🎉 You're doing amazing!");
    else if (score >= 30) setLevelMessage("Great progress, keep going! 🚀");
    else setLevelMessage("Nice! You earned 10 points 🏆");

    setMood("");
    setJournal("");
  };

  const handleActivityClick = () => {
    setScore(score + 10);
    setLevelMessage("🎯 +10 points! You’re building healthy habits!");
  };

  const handlePeerSend = () => {
    if (!peerMessage.trim()) return;
    const msg = { sender: "Anon", text: peerMessage };
    setPeerMessages([...peerMessages, msg]);
    setPeerMessage("");
  };

  const handleSendMessage = () => {
    if (!userMessage.trim()) return;
    const userMsg = { sender: "You", text: userMessage };
    setChatMessages([...chatMessages, userMsg]);
    setUserMessage("");

    setTimeout(() => {
      const replies = [
        "That’s a great step, keep sharing! 🌟",
        "You’re not alone. Want to try journaling today?",
        "Let’s breathe deeply together.",
      ];
      const reply = {
        sender: "Therapist",
        text: replies[Math.floor(Math.random() * replies.length)],
      };
      setChatMessages((prev) => [...prev, reply]);
    }, 1500);
  };

  const moodData = moodHistory.map((entry) => ({
    time: entry.time,
    mood: entry.mood,
  }));

  const stressData = stressHistory.map((entry) => ({
    time: entry.time,
    stress: entry.stress,
  }));

  return (
    <div className="App">
      <header className="header">Mental Health Companion</header>
      <div className="top-panel">
        <div className="score">Score: {score} 🎮</div>
        <div className="level-msg">{levelMessage}</div>
      </div>

      <div className="main-layout">
        <div className="left-panel">
          <div className="check-in">
            <h3>Mood Check-In</h3>
            <input
              type="text"
              value={mood}
              onChange={(e) => setMood(e.target.value)}
              placeholder="How are you feeling?"
            />
            <div className="emoji-bar">
              {emojis.map((e, i) => (
                <button key={i} onClick={() => setMood(mood + e)}>{e}</button>
              ))}
            </div>
            <input
              type="range"
              min="1"
              max="10"
              value={stress}
              onChange={(e) => setStress(Number(e.target.value))}
            />
            <p>Stress Level: {stress}</p>
            <button onClick={handleCheckIn}>Submit</button>
          </div>

          <div className="routine-section">
            <h3>Personalized Routine</h3>
            <ul>
              {personalRoutine.map((item, idx) => (
                <li key={idx} className="routine-item">{item}</li>
              ))}
            </ul>
          </div>

          <div className="graph-box">
            <h4>Stress Trends</h4>
            <ResponsiveContainer width="100%" height={180}>
              <BarChart data={stressData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="time" angle={-30} />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="stress" fill="#84d2c5" />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="peer-support">
            <h3>Anonymous Peer Chat</h3>
            <div className="peer-box">
              {peerMessages.map((m, i) => (
                <div key={i} className="peer-msg"><strong>{m.sender}:</strong> {m.text}</div>
              ))}
            </div>
            <div className="peer-input">
              <input
                type="text"
                placeholder="Type your message..."
                value={peerMessage}
                onChange={(e) => setPeerMessage(e.target.value)}
              />
              <button onClick={handlePeerSend}>Send</button>
            </div>
          </div>
        </div>

        <div className="right-panel">
          <div className="activities">
            <h3>AI-Driven Activities</h3>
            {activitySuggestions.map((act, idx) => (
              <div key={idx} className="activity-card" onClick={handleActivityClick}>
                {act}
              </div>
            ))}
          </div>

          <div className="mood-journal">
            <h3>📝 Mood Journal</h3>
            <textarea
              placeholder="Write your thoughts..."
              value={journal}
              onChange={(e) => setJournal(e.target.value)}
            />
          </div>

          <div className="therapist-chat">
            <h3>Chat with Therapist</h3>
            <div className="chat-box">
              {chatMessages.map((msg, i) => (
                <div
                  key={i}
                  className={msg.sender === "You" ? "chat-user" : "chat-therapist"}
                >
                  <strong>{msg.sender}:</strong> {msg.text}
                </div>
              ))}
            </div>
            <div className="chat-input">
              <input
                type="text"
                placeholder="Type your message..."
                value={userMessage}
                onChange={(e) => setUserMessage(e.target.value)}
              />
              <button onClick={handleSendMessage}>Send</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
