import React from "react";
import {
    LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, BarChart, Bar
} from "recharts";

const MoodDashboard = ({ moodHistory, stressHistory }) => {
    const moodData = moodHistory.map((entry, index) => {
        const [mood, time] = entry.split(" - ");
        return { name: `#${moodHistory.length - index}`, mood };
    });

    const stressData = stressHistory.map((entry, index) => ({
        name: `#${stressHistory.length - index}`,
        stress: entry.level,
    }));

    return (
        <div className="dashboard-charts">
            <h2>📊 Mood & Stress Trends</h2>
            <div className="chart-wrapper">
                <ResponsiveContainer width="100%" height={200}>
                    <LineChart data={moodData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Line type="monotone" dataKey="mood" stroke="#8884d8" />
                    </LineChart>
                </ResponsiveContainer>
            </div>
            <div className="chart-wrapper">
                <ResponsiveContainer width="100%" height={200}>
                    <BarChart data={stressData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="stress" fill="#82ca9d" />
                    </BarChart>
                </ResponsiveContainer>
            </div>
        </div>
    );
};

export default MoodDashboard;
